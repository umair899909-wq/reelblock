# ReelBlock

Private, offline blocker for Instagram Reels, YouTube Shorts, Facebook Reels and TikTok.
No internet permission, no libraries, no tracking. Two short Java files you can read yourself.

## What it does
- Reels tab / Shorts tab: closed instantly.
- A single reel opened from a DM or link: allowed for 90 seconds, then closed and
  short videos lock for 5 minutes (can be switched to "block everything").
- TikTok: whole app closed.
- Strict mode: weakening any setting needs a 60 second wait.
- Counter of blocks today and all time.

## Get the APK (free, no PC needed)
1. Create a GitHub account, then a new repository (Private is fine).
2. Upload all files from this folder, keeping the folder structure,
   including `.github/workflows/build.yml`.
3. Open the **Actions** tab. "Build APK" runs automatically (about 3 minutes).
4. Open the finished run, download **ReelBlock-apk**, unzip it, install `app-debug.apk`.

## Install and turn on
1. Open the APK on your phone and allow "install unknown apps".
2. Open ReelBlock, tap **Open Accessibility settings**, pick ReelBlock, turn it ON.
3. Android 13+: if the switch is greyed out ("Restricted setting"), tap
   **Open app info** in ReelBlock, then the three dots at the top right,
   then **Allow restricted settings**, and try again.
4. Xiaomi, Oppo, Vivo, Samsung and similar phones stop background services:
   in app info set battery usage to **Unrestricted** (and allow autostart if offered).

## If it stops working after an app update
Turn on **Debug**, open the Reels/Shorts screen, return to ReelBlock and press **Copy IDs**.
The first lines say whether the feed or viewer was detected. Add the new ID to
`IG_TAB_IDS`, `IG_VIEWER_IDS` or `YT_VIEWER_IDS` in `BlockerService.java` and rebuild.
