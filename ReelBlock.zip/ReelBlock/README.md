# Mushin (formerly ReelBlock)

Mushin (no-mind) is a private, offline blocker for Instagram Reels, YouTube Shorts,
Facebook Reels and TikTok, shaped by Zen and the teachings of Miyamoto Musashi.
No internet permission, no libraries, no tracking.

The teachings shown in the app are plain-English paraphrases, not exact translations.
The folder and zip keep the name ReelBlock so the GitHub build keeps working.

## What it does
- Reels tab / Shorts tab: closed instantly.
- The full-screen reel player, however you reach it (home feed, DM, link, Explore,
  or the app reopening on a reel): closed instantly.
- One-reel mode (optional): one reel may play for up to 90 seconds; swiping to the
  next one closes it and locks short videos for 5 minutes.
- TikTok: whole app closed.
- Strict mode: weakening any setting needs a 60 second wait.
- Pause for 10 minutes; blocking switches back on by itself.
- Stats: blocks today, all time, and a 7-day chart.

## Get the APK (free, no PC needed)
1. Create a GitHub account, then a new repository (Private is fine).
2. Upload all files from this folder, keeping the folder structure,
   including `.github/workflows/build.yml`.
3. Open the **Actions** tab. "Build APK" runs automatically (about 3 minutes).
4. Open the finished run, download **ReelBlock-apk**, unzip it, install `app-debug.apk`.

## Install and turn on
1. Open the APK on your phone and allow "install unknown apps".
2. Open Mushin, tap **Open Accessibility settings**, pick Mushin, turn it ON.
3. Android 13+: if the switch is greyed out ("Restricted setting"), tap
   **Open app info** in Mushin, then the three dots at the top right,
   then **Allow restricted settings**, and try again.
4. Xiaomi, Oppo, Vivo, Samsung and similar phones stop background services:
   in app info set battery usage to **Unrestricted** (and allow autostart if offered).

## If it stops working after an app update
Turn on **Debug**, open the Reels/Shorts screen, return to Mushin and press **Copy IDs**.
The first lines say whether the tab and the player were detected. Add the new name to
`IG_TAB_IDS`, `IG_PLAYER_HINTS` or `YT_PLAYER_HINTS` in `BlockerService.java` and rebuild.
