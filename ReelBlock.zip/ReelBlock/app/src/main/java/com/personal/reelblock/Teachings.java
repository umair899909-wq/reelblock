package com.personal.reelblock;

import android.content.SharedPreferences;

import java.util.Random;

/**
 * Short teachings shown on the home screen, in the block message and in the
 * strict-mode wait. They are plain-English paraphrases, not exact translations,
 * which is why each source reads "after ...".
 */
final class Teachings {

    static final String MUSASHI = "after Miyamoto Musashi";
    static final String ZEN = "Zen saying";
    static final String SUN_TZU = "after Sun Tzu";
    static final String SHAFII = "after Imam al-Shafi’i";
    static final String QAYYIM = "after Ibn al-Qayyim";
    static final String SENECA = "after Seneca";
    static final String AURELIUS = "after Marcus Aurelius";
    static final String EPICTETUS = "after Epictetus";
    static final String NIZAMUDDIN = "after Nizamuddin Auliya of Delhi";
    static final String WALIULLAH = "after Shah Waliullah of Delhi";
    static final String SIR_SYED = "after Sir Syed Ahmad Khan of Delhi";

    static final String[][] ALL = {
            // Japan
            { "Do nothing that is of no use.", MUSASHI },
            { "Accept things exactly as they are.", MUSASHI },
            { "Do not chase pleasure for its own sake.", MUSASHI },
            { "Today, defeat who you were yesterday.", MUSASHI },
            { "Do not let a passing feeling decide for you.", MUSASHI },
            { "Think lightly of yourself and deeply of the world.", MUSASHI },
            { "Stay free of desire for as long as you live.", MUSASHI },
            { "See what the eye alone cannot see.", MUSASHI },
            { "Do not regret what is already done.", MUSASHI },
            { "Notice even the smallest things.", MUSASHI },
            { "The Way is found in practice.", MUSASHI },
            { "Never leave the Way.", MUSASHI },
            { "When walking, walk. When eating, eat.", ZEN },
            { "Chop wood. Carry water.", ZEN },
            { "Let go, or be dragged.", ZEN },
            // China
            { "The greatest victory is the one won without a fight.", SUN_TZU },
            { "Know your enemy and know yourself, and a hundred battles hold no danger.", SUN_TZU },
            { "The one who knows when to fight and when not to will win.", SUN_TZU },
            { "The wise warrior wins first, and only then goes to battle.", SUN_TZU },
            // Arab scholars
            { "Time is a sword. Cut with it, or it cuts you.", SHAFII },
            { "Keep yourself busy with what is true, or you will be kept busy with what is false.", SHAFII },
            { "Wasting time is worse than death. Death parts you from this world; wasted time parts you from God.", QAYYIM },
            // Rome and Greece
            { "Life is not short. We waste most of it.", SENECA },
            { "While we keep putting things off, life runs past.", SENECA },
            { "Your mind takes the colour of your thoughts.", AURELIUS },
            { "No one is free who is not master of himself.", EPICTETUS },
            // Delhi
            { "The one who serves becomes the master.", NIZAMUDDIN },
            { "Clear away the fog of the ego, and reason grows strong.", WALIULLAH },
            { "Let your character, knowledge and patience show what you believe.", SIR_SYED },
    };

    private static final Random RANDOM = new Random();
    private static final String KEY_LAST = "last_teaching";

    /** A random teaching that is never the same as the one shown last time. */
    static String[] next(SharedPreferences prefs) {
        int last = prefs.getInt(KEY_LAST, -1);
        int i = RANDOM.nextInt(ALL.length);
        if (i == last) i = (i + 1) % ALL.length;
        prefs.edit().putInt(KEY_LAST, i).apply();
        return ALL[i];
    }

    static String[] random() {
        return ALL[RANDOM.nextInt(ALL.length)];
    }

    private Teachings() { }
}
