package com.personal.reelblock;

import java.time.LocalDate;
import java.util.Random;

/**
 * Short teachings shown on the home screen, in the block message and in the
 * strict-mode wait. They are plain-English paraphrases, not exact translations:
 * the Musashi lines follow ideas from his Dokkodo ("The Way of Walking Alone")
 * and The Book of Five Rings; the rest are traditional Zen sayings.
 */
final class Teachings {

    static final String MUSASHI = "after Miyamoto Musashi";
    static final String ZEN = "Zen saying";

    static final String[][] ALL = {
            { "Do nothing that is of no use.", MUSASHI },
            { "Accept things exactly as they are.", MUSASHI },
            { "Do not chase pleasure for its own sake.", MUSASHI },
            { "Today, defeat who you were yesterday.", MUSASHI },
            { "When walking, walk. When eating, eat.", ZEN },
            { "Do not let a passing feeling decide for you.", MUSASHI },
            { "Think lightly of yourself and deeply of the world.", MUSASHI },
            { "Chop wood. Carry water.", ZEN },
            { "Stay free of desire for as long as you live.", MUSASHI },
            { "See what the eye alone cannot see.", MUSASHI },
            { "Let go, or be dragged.", ZEN },
            { "Do not regret what is already done.", MUSASHI },
            { "Notice even the smallest things.", MUSASHI },
            { "The Way is found in practice.", MUSASHI },
            { "Never leave the Way.", MUSASHI },
    };

    /** The teaching for today; offset steps forward through the list. */
    static String[] forToday(int offset) {
        return ALL[(int) Math.floorMod(LocalDate.now().toEpochDay() + offset, (long) ALL.length)];
    }

    static String[] random(Random r) {
        return ALL[r.nextInt(ALL.length)];
    }

    private Teachings() { }
}
