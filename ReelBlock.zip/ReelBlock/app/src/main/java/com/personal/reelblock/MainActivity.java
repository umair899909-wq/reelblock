package com.personal.reelblock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;

public class MainActivity extends Activity {

    static final String PREFS = "reelblock";
    static final String KEY_IG = "block_ig";
    static final String KEY_YT = "block_yt";
    static final String KEY_FB = "block_fb";
    static final String KEY_TIKTOK = "block_tiktok";
    static final String KEY_GRACE = "allow_single";
    static final String KEY_STRICT = "strict";
    static final String KEY_DEBUG = "debug";
    static final String KEY_COUNT = "count";
    static final String KEY_DAY = "day";
    static final String KEY_TODAY = "today";
    static final String KEY_IDS = "last_ids";

    static final int STRICT_WAIT_SECONDS = 60;

    private SharedPreferences prefs;
    private TextView status, count, ids;
    private int pad;
    private boolean internalChange;

    static String today() {
        return LocalDate.now().toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        pad = (int) (20 * getResources().getDisplayMetrics().density);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("ReelBlock");
        title.setTextSize(28);
        box.addView(title);
        box.addView(text("Blocks Reels and Shorts, keeps the rest of each app working. "
                + "No internet permission: nothing ever leaves your phone."));

        status = new TextView(this);
        status.setTextSize(18);
        status.setPadding(0, pad, 0, pad / 4);
        box.addView(status);

        count = new TextView(this);
        count.setPadding(0, 0, 0, pad / 2);
        box.addView(count);

        Button open = new Button(this);
        open.setText("Open Accessibility settings");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(open);

        Button info = new Button(this);
        info.setText("Open app info (battery, restricted settings)");
        info.setOnClickListener(v -> startActivity(new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        box.addView(info);

        box.addView(header("What to block"));
        box.addView(toggle("Instagram Reels", KEY_IG, true, Boolean.FALSE));
        box.addView(toggle("YouTube Shorts", KEY_YT, true, Boolean.FALSE));
        box.addView(toggle("Facebook Reels", KEY_FB, true, Boolean.FALSE));
        box.addView(toggle("TikTok (whole app)", KEY_TIKTOK, true, Boolean.FALSE));

        box.addView(header("Reels people send you"));
        box.addView(toggle("Allow a single reel from DMs or links", KEY_GRACE, true, Boolean.TRUE));
        box.addView(text("On: a reel opened from a chat or link can play for 90 seconds. "
                + "If you stay longer, it closes and short videos lock for 5 minutes. "
                + "The Reels and Shorts tabs are always blocked.\n"
                + "Off: every reel is closed at once."));

        box.addView(header("Strict mode"));
        box.addView(toggle("Make blocking hard to turn off", KEY_STRICT, false, Boolean.FALSE));
        box.addView(text("When on, weakening any setting here needs a "
                + STRICT_WAIT_SECONDS + " second wait, long enough for the urge to pass."));

        box.addView(header("Troubleshooting"));
        box.addView(toggle("Debug: record screen element IDs", KEY_DEBUG, false, null));
        ids = new TextView(this);
        ids.setTextIsSelectable(true);
        ids.setTextSize(12);
        box.addView(ids);

        Button copy = new Button(this);
        copy.setText("Copy IDs");
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("ids", prefs.getString(KEY_IDS, "")));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
        });
        box.addView(copy);

        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        scroll.addView(box);
        setContentView(scroll);
    }

    private TextView header(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(18);
        t.setPadding(0, pad, 0, pad / 4);
        return t;
    }

    private TextView text(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        return t;
    }

    /**
     * weakValue is the switch position that makes blocking weaker (null = harmless setting).
     * In strict mode, moving a switch to that position needs a wait first.
     */
    private Switch toggle(String label, String key, boolean def, Boolean weakValue) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(16);
        s.setChecked(prefs.getBoolean(key, def));
        s.setPadding(0, pad / 2, 0, pad / 2);
        s.setOnCheckedChangeListener((b, on) -> {
            if (internalChange) return;
            boolean weakens = weakValue != null && weakValue == on;
            if (weakens && prefs.getBoolean(KEY_STRICT, false)) {
                setQuietly(s, !on); // put it back until the wait is over
                waitThen(label, () -> {
                    setQuietly(s, on);
                    prefs.edit().putBoolean(key, on).apply();
                });
                return;
            }
            prefs.edit().putBoolean(key, on).apply();
        });
        return s;
    }

    private void setQuietly(Switch s, boolean value) {
        internalChange = true;
        s.setChecked(value);
        internalChange = false;
    }

    private void waitThen(String label, Runnable action) {
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Strict mode")
                .setMessage("You are about to weaken: " + label
                        + ".\n\nWait for the timer if you really mean it.")
                .setNegativeButton("Keep blocking", null)
                .setPositiveButton("Wait", (x, w) -> action.run())
                .create();
        d.show();
        Button ok = d.getButton(AlertDialog.BUTTON_POSITIVE);
        ok.setEnabled(false);
        CountDownTimer timer = new CountDownTimer(STRICT_WAIT_SECONDS * 1000L, 1000) {
            @Override public void onTick(long ms) {
                ok.setText("Wait " + (ms / 1000 + 1) + "s");
            }
            @Override public void onFinish() {
                ok.setText("Change it");
                ok.setEnabled(true);
            }
        };
        timer.start();
        d.setOnDismissListener(x -> timer.cancel());
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean on = isServiceEnabled();
        status.setText(on ? "● Blocker is ON"
                : "○ Blocker is OFF. Turn on \"ReelBlock\" in Accessibility.");
        status.setTextColor(on ? Color.rgb(0, 150, 70) : Color.rgb(210, 50, 50));
        int todayCount = today().equals(prefs.getString(KEY_DAY, "")) ? prefs.getInt(KEY_TODAY, 0) : 0;
        count.setText("Blocked today: " + todayCount + "   |   all time: " + prefs.getInt(KEY_COUNT, 0));
        String last = prefs.getString(KEY_IDS, "");
        ids.setText(last.isEmpty()
                ? "(Turn on Debug, open the Reels or Shorts screen, then come back here.)" : last);
    }

    private boolean isServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName cn = new ComponentName(this, BlockerService.class);
        return enabled.contains(cn.flattenToString()) || enabled.contains(cn.flattenToShortString());
    }
}
