package com.personal.reelblock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    static final String PREFS = "reelblock";
    static final String KEY_IG = "block_ig";
    static final String KEY_YT = "block_yt";
    static final String KEY_FB = "block_fb";
    static final String KEY_TIKTOK = "block_tiktok";
    static final String KEY_ALLOW_ONE = "allow_one_reel";
    static final String KEY_STRICT = "strict";
    static final String KEY_DEBUG = "debug";
    static final String KEY_COUNT = "count";
    static final String KEY_IDS = "last_ids";
    static final String KEY_ERROR = "last_error";
    static final String KEY_PAUSE_UNTIL = "pause_until";
    static final String KEY_GUARD = "guard_on";
    static final String DAY_PREFIX = "d_";

    static final int STRICT_WAIT_SECONDS = 60;
    static final long PAUSE_MS = 10 * 60_000;

    // Colours: sumi ink, washi paper, vermilion seal
    static final int CARD = 0xFF181715;
    static final int LINE = 0xFF2E2B27;
    static final int TEXT = 0xFFEDE6DA;
    static final int MUTED = 0xFF8F887C;
    static final int STONE = 0xFF5C574F;
    static final int ACCENT = 0xFFC8452F;

    private SharedPreferences prefs;
    private LinearLayout hero, setup, chart, fixBox, streakBar;
    private TextView heroEmoji, heroTitle, heroSub, heroHint, teachText, teachSrc;
    private TextView streakNum, streakRank, streakNext, todayNum, totalNum, pauseBtn, ids;
    private boolean internalChange;

    static String today() {
        return LocalDate.now().toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(28));

        // ---- header
        page.addView(label("Mushin", 30, TEXT, true));
        page.addView(label("無心  ·  a still mind does not scroll", 14, MUTED, false));

        // ---- status: tap the whole card to raise or lower the guard
        hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        heroEmoji = label("", 40, TEXT, false);
        heroTitle = label("", 22, TEXT, true);
        heroSub = label("", 14, MUTED, false);
        heroHint = label("", 12, MUTED, true);
        hero.addView(heroEmoji);
        hero.addView(heroTitle);
        hero.addView(heroSub);
        hero.addView(heroHint, margins(10));
        hero.setOnClickListener(v -> onHeroClicked());
        page.addView(hero, margins(16));

        // ---- teaching (a new one every time the app opens; tap for another)
        LinearLayout teach = card();
        teachText = label("", 18, TEXT, false);
        teachSrc = label("", 12, MUTED, false);
        teach.addView(teachText);
        teach.addView(teachSrc, margins(8));
        teach.setOnClickListener(v -> showTeaching());
        page.addView(teach, margins(12));

        // ---- setup steps (only shown while Mushin is off in Accessibility)
        setup = card();
        setup.addView(label("Raise your guard (20 seconds)", 16, TEXT, true));
        setup.addView(label("1. Tap the button below, pick Mushin, switch it on.\n"
                + "2. Switch greyed out? Open App info, tap the 3 dots, then "
                + "\"Allow restricted settings\", and try again.\n"
                + "3. In App info set Battery to Unrestricted so your phone doesn't kill it.",
                14, MUTED, false), margins(6));
        TextView openAcc = pill("Open Accessibility settings", ACCENT, TEXT);
        openAcc.setOnClickListener(v -> openAccessibility());
        setup.addView(openAcc, margins(12));
        TextView openInfo = pill("App info", LINE, TEXT);
        openInfo.setOnClickListener(v -> openAppInfo());
        setup.addView(openInfo, margins(8));
        page.addView(setup, margins(12));

        // ---- streak
        LinearLayout streak = card();
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.BOTTOM);
        streakNum = label("0", 44, TEXT, true);
        top.addView(streakNum);
        TextView unit = label("  days on the Way", 14, MUTED, false);
        unit.setPadding(0, 0, 0, dp(8));
        top.addView(unit);
        streak.addView(top);
        streakRank = label("", 16, ACCENT, true);
        streak.addView(streakRank);
        streakBar = new LinearLayout(this);
        streakBar.setOrientation(LinearLayout.HORIZONTAL);
        streak.addView(streakBar, margins(12));
        streakNext = label("", 13, MUTED, false);
        streak.addView(streakNext, margins(8));
        streak.addView(label("Lowering your guard ends the streak. One rest a day is free.",
                12, STONE, false), margins(6));
        page.addView(streak, margins(12));

        // ---- stats
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        todayNum = label("0", 34, TEXT, true);
        totalNum = label("0", 34, TEXT, true);
        LinearLayout a = statCard(todayNum, "cut today");
        LinearLayout b = statCard(totalNum, "cut all time");
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        la.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lb.setMargins(dp(6), 0, 0, 0);
        stats.addView(a, la);
        stats.addView(b, lb);
        page.addView(stats, margins(12));

        LinearLayout week = card();
        week.addView(label("Last 7 days", 16, TEXT, true));
        chart = new LinearLayout(this);
        chart.setOrientation(LinearLayout.HORIZONTAL);
        chart.setGravity(Gravity.BOTTOM);
        week.addView(chart, margins(12));
        page.addView(week, margins(12));

        // ---- what to block
        page.addView(label("WHAT TO CUT AWAY", 12, MUTED, true), margins(22));
        LinearLayout apps = card();
        apps.addView(toggleRow("Instagram Reels", null, KEY_IG, true, Boolean.FALSE));
        apps.addView(toggleRow("YouTube Shorts", null, KEY_YT, true, Boolean.FALSE));
        apps.addView(toggleRow("Facebook Reels", null, KEY_FB, true, Boolean.FALSE));
        apps.addView(toggleRow("TikTok", "Closes the whole app", KEY_TIKTOK, true, Boolean.FALSE));
        page.addView(apps, margins(8));

        // ---- modes
        page.addView(label("DISCIPLINE", 12, MUTED, true), margins(22));
        LinearLayout modes = card();
        modes.addView(toggleRow("One-reel mode",
                "Watch a single reel (like one a friend sent) for up to 90 sec. "
                        + "Swipe to the next one and reels lock for 5 min. "
                        + "Off = every reel closes right away.",
                KEY_ALLOW_ONE, false, Boolean.TRUE));
        modes.addView(toggleRow("Strict mode",
                "Lowering your guard or turning anything off makes you wait "
                        + STRICT_WAIT_SECONDS + " sec and breathe first. Urges pass; the Way stays.",
                KEY_STRICT, false, Boolean.FALSE));
        page.addView(modes, margins(8));

        // ---- rest
        page.addView(label("REST", 12, MUTED, true), margins(22));
        LinearLayout brk = card();
        brk.addView(label("Lower your guard for 10 minutes. It rises again by itself.", 14, MUTED, false));
        pauseBtn = pill("", LINE, TEXT);
        pauseBtn.setOnClickListener(v -> onPauseClicked());
        brk.addView(pauseBtn, margins(12));
        page.addView(brk, margins(8));

        // ---- troubleshooting (folded away)
        TextView fixHeader = label("Something not getting blocked? Tap here", 14, MUTED, true);
        fixHeader.setPadding(0, dp(8), 0, dp(8));
        page.addView(fixHeader, margins(22));
        fixBox = card();
        fixBox.setVisibility(View.GONE);
        fixBox.addView(label("1. Turn on Debug below.\n2. Open the reel that wasn't blocked.\n"
                + "3. Come back here, tap Copy, and send the text to whoever maintains your app.",
                14, MUTED, false));
        fixBox.addView(toggleRow("Debug", "Notes which screen parts are showing. Stays on your phone.",
                KEY_DEBUG, false, null));
        ids = label("", 11, MUTED, false);
        ids.setTextIsSelectable(true);
        fixBox.addView(ids, margins(8));
        TextView copy = pill("Copy", ACCENT, TEXT);
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("ids", debugText()));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
        });
        fixBox.addView(copy, margins(12));
        TextView info2 = pill("App info (battery, restricted settings)", LINE, TEXT);
        info2.setOnClickListener(v -> openAppInfo());
        fixBox.addView(info2, margins(8));
        page.addView(fixBox, margins(4));
        fixHeader.setOnClickListener(v ->
                fixBox.setVisibility(fixBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));

        // ---- footer
        TextView foot = label("No internet permission. Nothing leaves your phone.", 12, MUTED, false);
        foot.setGravity(Gravity.CENTER);
        page.addView(foot, margins(24));

        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        scroll.addView(page);
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        showTeaching(); // a different one every time the app comes to the front
        refresh();
    }

    // ---------------------------------------------------------------- state

    private boolean paused() {
        return System.currentTimeMillis() < prefs.getLong(KEY_PAUSE_UNTIL, 0);
    }

    private void refresh() {
        boolean service = isServiceEnabled();
        boolean guard = prefs.getBoolean(KEY_GUARD, true);
        boolean paused = paused();

        if (!service) {
            Streak.end(prefs);
            hero.setBackground(box(CARD, 24, ACCENT));
            heroEmoji.setText("隙"); // suki: an opening in one's guard
            heroTitle.setText("Your guard is down");
            heroSub.setText("Mushin is switched off in Accessibility. Reels can reach you.");
            heroHint.setText("TAP TO OPEN SETTINGS");
        } else if (!guard) {
            hero.setBackground(box(CARD, 24, ACCENT));
            heroEmoji.setText("鞘"); // saya: the scabbard
            heroTitle.setText("The blade is sheathed");
            heroSub.setText("You lowered your guard. Reels can reach you.");
            heroHint.setText("TAP TO RAISE YOUR GUARD");
        } else if (paused) {
            hero.setBackground(box(CARD, 24, STONE));
            heroEmoji.setText("休"); // rest
            heroTitle.setText("Resting");
            heroSub.setText("Your guard rises again at "
                    + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(prefs.getLong(KEY_PAUSE_UNTIL, 0))) + ".");
            heroHint.setText("TAP TO RAISE YOUR GUARD NOW");
        } else {
            Streak.begin(prefs);
            hero.setBackground(box(CARD, 24, TEXT));
            heroEmoji.setText("無心"); // mushin: no-mind
            heroTitle.setText("The mind is still");
            heroSub.setText("Reels and Shorts are cut away.");
            heroHint.setText("TAP TO LOWER YOUR GUARD");
        }
        setup.setVisibility(service ? View.GONE : View.VISIBLE);

        drawStreak();
        todayNum.setText(String.valueOf(prefs.getInt(DAY_PREFIX + today(), 0)));
        totalNum.setText(String.valueOf(prefs.getInt(KEY_COUNT, 0)));
        drawChart();

        if (paused) pauseBtn.setText("Raise guard now");
        else pauseBtn.setText(Streak.restedToday(prefs)
                ? "Rest for 10 min (ends your streak)" : "Rest for 10 min (free today)");
        pauseBtn.setBackground(box(paused ? ACCENT : LINE, 16, 0));

        ids.setText(debugText());
    }

    private String debugText() {
        String last = prefs.getString(KEY_IDS, "");
        if (!last.isEmpty()) return last;
        return "(nothing recorded yet)\nlast error: " + prefs.getString(KEY_ERROR, "none");
    }

    /** Tapping the big status card raises or lowers the guard. */
    private void onHeroClicked() {
        if (!isServiceEnabled()) {
            openAccessibility();
            return;
        }
        if (!prefs.getBoolean(KEY_GUARD, true)) {
            prefs.edit().putBoolean(KEY_GUARD, true).apply();
            Toast.makeText(this, "Guard raised", Toast.LENGTH_SHORT).show();
            refresh();
            return;
        }
        if (paused()) {
            prefs.edit().remove(KEY_PAUSE_UNTIL).apply();
            Toast.makeText(this, "Guard raised", Toast.LENGTH_SHORT).show();
            refresh();
            return;
        }
        Runnable lower = () -> {
            prefs.edit().putBoolean(KEY_GUARD, false).apply();
            Streak.end(prefs);
            Toast.makeText(this, "Guard lowered", Toast.LENGTH_SHORT).show();
            refresh();
        };
        if (prefs.getBoolean(KEY_STRICT, false)) waitThen("lower your guard and end your streak", lower);
        else lower.run();
    }

    private void onPauseClicked() {
        if (paused()) {
            prefs.edit().remove(KEY_PAUSE_UNTIL).apply();
            refresh();
            return;
        }
        Runnable start = () -> {
            Streak.rest(prefs);
            prefs.edit().putLong(KEY_PAUSE_UNTIL, System.currentTimeMillis() + PAUSE_MS).apply();
            refresh();
        };
        if (prefs.getBoolean(KEY_STRICT, false)) waitThen("rest for 10 min", start);
        else start.run();
    }

    private void showTeaching() {
        String[] t = Teachings.next(prefs);
        teachText.setText(t[0]);
        teachSrc.setText("— " + t[1] + "   (tap for another)");
    }

    // ---------------------------------------------------------------- drawing

    private void drawStreak() {
        int days = Streak.days(prefs);
        int best = Streak.best(prefs);
        int rank = Streak.rank(days);
        streakNum.setText(String.valueOf(days));
        streakRank.setText(rank < 0 ? "Raise your guard to begin" : Streak.NAMES[rank]);

        int from = rank < 0 ? 0 : Streak.STEPS[rank];
        boolean top = rank == Streak.STEPS.length - 1;
        int to = top ? from : Streak.STEPS[rank + 1];
        float done = top ? 1f : (days - from) / (float) (to - from);

        streakBar.removeAllViews();
        View filled = new View(this);
        filled.setBackground(box(ACCENT, 3, 0));
        View empty = new View(this);
        empty.setBackground(box(LINE, 3, 0));
        streakBar.addView(filled, new LinearLayout.LayoutParams(0, dp(6), Math.max(done, 0.02f)));
        streakBar.addView(empty, new LinearLayout.LayoutParams(0, dp(6), Math.max(1f - done, 0.001f)));

        String next = top ? "You have reached the last rank."
                : (to - days) + (to - days == 1 ? " day" : " days") + " to \"" + Streak.NAMES[rank + 1] + "\"";
        streakNext.setText(next + "   ·   best: " + best + (best == 1 ? " day" : " days"));
    }

    private void drawChart() {
        chart.removeAllViews();
        LocalDate now = LocalDate.now();
        int[] counts = new int[7];
        int max = 1;
        for (int i = 0; i < 7; i++) {
            counts[i] = prefs.getInt(DAY_PREFIX + now.minusDays(6 - i), 0);
            max = Math.max(max, counts[i]);
        }
        for (int i = 0; i < 7; i++) {
            LocalDate day = now.minusDays(6 - i);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);

            TextView n = label(String.valueOf(counts[i]), 11, MUTED, false);
            n.setGravity(Gravity.CENTER);
            col.addView(n);

            View bar = new View(this);
            bar.setBackground(box(i == 6 ? ACCENT : STONE, 3, 0));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(18), dp(4 + 56f * counts[i] / max));
            bp.setMargins(0, dp(4), 0, dp(4));
            col.addView(bar, bp);

            String name = day.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
            TextView d = label(name.substring(0, 2), 11, i == 6 ? TEXT : MUTED, i == 6);
            d.setGravity(Gravity.CENTER);
            col.addView(d);

            chart.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
    }

    private void openAccessibility() {
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    private void openAppInfo() {
        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName())));
    }

    // ---------------------------------------------------------------- building blocks

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable box(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1.5f), strokeColor);
        return g;
    }

    private LinearLayout.LayoutParams margins(float topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(topDp), 0, 0);
        return lp;
    }

    private TextView label(String s, float sizeSp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLineSpacing(dp(2), 1f);
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        c.setBackground(box(CARD, 22, 0));
        return c;
    }

    private LinearLayout statCard(TextView number, String caption) {
        LinearLayout c = card();
        c.addView(number);
        c.addView(label(caption, 13, MUTED, false));
        return c;
    }

    private TextView pill(String s, int bg, int fg) {
        TextView t = label(s, 15, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(14), dp(16), dp(14));
        t.setBackground(box(bg, 16, 0));
        t.setClickable(true);
        return t;
    }

    /**
     * A row with a title, optional explanation and a switch. weakValue is the switch
     * position that makes blocking weaker (null = harmless setting); in strict mode,
     * moving to that position needs a wait first.
     */
    private LinearLayout toggleRow(String title, String sub, String key, boolean def, Boolean weakValue) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.addView(label(title, 16, TEXT, true));
        if (sub != null) texts.addView(label(sub, 13, MUTED, false));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(0, 0, dp(12), 0);
        row.addView(texts, tp);

        Switch s = new Switch(this);
        s.setChecked(prefs.getBoolean(key, def));
        s.setOnCheckedChangeListener((b, on) -> {
            if (internalChange) return;
            boolean weakens = weakValue != null && weakValue == on;
            if (weakens && prefs.getBoolean(KEY_STRICT, false)) {
                setQuietly(s, !on); // put it back until the wait is over
                waitThen("change \"" + title + "\"", () -> {
                    setQuietly(s, on);
                    prefs.edit().putBoolean(key, on).apply();
                });
                return;
            }
            prefs.edit().putBoolean(key, on).apply();
        });
        row.addView(s);
        row.setOnClickListener(v -> s.toggle());
        return row;
    }

    private void setQuietly(Switch s, boolean value) {
        internalChange = true;
        s.setChecked(value);
        internalChange = false;
    }

    private void waitThen(String what, Runnable action) {
        String[] t = Teachings.random();
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Breathe")
                .setMessage("“" + t[0] + "”\n— " + t[1]
                        + "\n\nStrict mode is on. You are about to " + what
                        + ". Breathe until the timer ends, then decide.")
                .setNegativeButton("Stay on the Way", null)
                .setPositiveButton("Wait", (x, w) -> action.run())
                .create();
        d.show();
        Button ok = d.getButton(AlertDialog.BUTTON_POSITIVE);
        ok.setEnabled(false);
        CountDownTimer timer = new CountDownTimer(STRICT_WAIT_SECONDS * 1000L, 1000) {
            @Override public void onTick(long ms) {
                ok.setText("Wait " + (ms / 1000 + 1) + "s");
            }
            @Override public void onFinish() {
                ok.setText("Proceed");
                ok.setEnabled(true);
            }
        };
        timer.start();
        d.setOnDismissListener(x -> timer.cancel());
    }

    private boolean isServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName cn = new ComponentName(this, BlockerService.class);
        return enabled.contains(cn.flattenToString()) || enabled.contains(cn.flattenToShortString());
    }
}
