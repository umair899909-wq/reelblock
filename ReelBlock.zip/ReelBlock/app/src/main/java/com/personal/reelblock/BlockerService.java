package com.personal.reelblock;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Watches ONLY Instagram, YouTube, Facebook and TikTok (see accessibility_config.xml).
 *
 * Two kinds of screen are recognised:
 *  1. The Reels / Shorts TAB in the navigation bar          -> closed instantly.
 *  2. The full-screen reel PLAYER, however you got there
 *     (feed, DM, link, Explore, app reopened mid-reel)      -> closed instantly, or, if
 *     "One-reel mode" is on, it may play once: swiping to the next reel or watching
 *     longer than 90 seconds closes it and locks short videos for 5 minutes.
 *
 * The player is found in two independent ways, so an app update rarely breaks both:
 *  a) known internal element names (e.g. Instagram's "clips_viewer"), and
 *  b) its shape: a vertical list where exactly one item fills the whole screen.
 *
 * Nothing is stored except block counters and (only with Debug on) on-screen element
 * names. The app has no internet permission.
 */
public class BlockerService extends AccessibilityService {

    static final String IG = "com.instagram.android";
    static final String YT = "com.google.android.youtube";
    static final String FB = "com.facebook.katana";
    static final Set<String> TIKTOK = new HashSet<>(Arrays.asList(
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill"));

    static final String[] IG_TAB_IDS = { "clips_tab" };
    // Parts of the internal names used by the full-screen players.
    // (Careful: inside Instagram "reel_viewer" means Stories, so it is not listed.)
    static final String[] IG_PLAYER_HINTS = { "clips_viewer", "clips_video", "clips_media" };
    static final String[] YT_PLAYER_HINTS = { "reel_player", "reel_watch", "reel_recycler", "shorts_player" };
    static final String[] NO_HINTS = {};

    static final long GRACE_MS = 90_000;        // longest a single allowed reel may play
    static final long COOLDOWN_MS = 5 * 60_000; // lock-out after a swipe or the time limit
    static final long SETTLE_MS = 700;          // time given to "Back" before checking again
    static final long START_IGNORE_MS = 1200;   // ignore movement while a reel is still opening
    static final long GONE_MS = 2500;           // player must be gone this long to count as closed
    static final long SHAPE_CONFIRM_MS = 400;   // a shape-only match must hold still this long

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable recheck = this::safeEvaluate;
    private final Runnable heartbeat = this::safeEvaluate;

    private SharedPreferences prefs;
    private long lastCheck, lastBlock, lastDebug;
    private int streak;
    private int screenH;
    private boolean foundByHint;
    private long shapeSince;

    // State of the player currently on screen (only used in one-reel mode).
    private long playerStart, playerLastSeen, cooldownUntil;
    private Set<String> baseline;   // words on screen when this reel started
    private int swipeIndex = -1;    // list position of this reel
    private int scrolled;           // pixels scrolled since this reel started (up minus down)
    private String lastScrollInfo = "";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }

    /** Mushin was switched off in Accessibility settings: the streak ends. */
    @Override
    public boolean onUnbind(android.content.Intent intent) {
        if (prefs != null) Streak.end(prefs);
        return super.onUnbind(intent);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        try {
            handleEvent(event);
        } catch (RuntimeException e) {
            noteError(e);
        }
    }

    private void safeEvaluate() {
        try {
            evaluate();
        } catch (RuntimeException e) {
            noteError(e);
        }
    }

    /** Remembers the last problem so it shows up in the Debug text. */
    private void noteError(RuntimeException e) {
        if (prefs != null) prefs.edit().putString(MainActivity.KEY_ERROR, String.valueOf(e)).apply();
    }

    private void handleEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (prefs == null) prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        long now = SystemClock.uptimeMillis();
        int type = event.getEventType();

        // A swipe inside an open player = moving on to the next reel = doomscrolling.
        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED
                && playerLastSeen > 0 && now - playerLastSeen < GONE_MS
                && now - playerStart > START_IGNORE_MS && now - lastBlock > SETTLE_MS
                && isReelSwipe(event)) {
            swiped();
            return;
        }

        // Always look once more after the screen has settled, so a throttled event is never missed.
        handler.removeCallbacks(recheck);
        handler.postDelayed(recheck, 350);

        boolean stateChange = type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        if (!stateChange && now - lastCheck < 250) return; // save battery
        lastCheck = now;
        evaluate();
    }

    private void evaluate() {
        if (prefs == null) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastBlock < SETTLE_MS) return;
        if (!prefs.getBoolean(MainActivity.KEY_GUARD, true)) return; // guard lowered by hand
        if (System.currentTimeMillis() < prefs.getLong(MainActivity.KEY_PAUSE_UNTIL, 0)) return; // resting
        Streak.begin(prefs);

        AccessibilityNodeInfo root;
        try {
            root = getRootInActiveWindow();
        } catch (RuntimeException e) {
            return;
        }
        if (root == null || root.getPackageName() == null) return;
        String pkg = root.getPackageName().toString();
        Rect screen = new Rect();
        root.getBoundsInScreen(screen);
        if (screen.height() > 0) screenH = screen.height();

        // TikTok is nothing but short videos, so the whole app is closed.
        if (TIKTOK.contains(pkg)) {
            if (on(MainActivity.KEY_TIKTOK, true)) block("TikTok is cut away.", true);
            return;
        }

        boolean tab;
        AccessibilityNodeInfo player;
        switch (pkg) {
            case IG:
                if (!on(MainActivity.KEY_IG, true)) return;
                tab = selectedById(root, pkg, IG_TAB_IDS) || selectedTab(root, "Reels", true);
                player = findPlayer(root, screen, IG_PLAYER_HINTS);
                break;
            case YT:
                if (!on(MainActivity.KEY_YT, true)) return;
                tab = selectedTab(root, "Shorts", true);
                player = findPlayer(root, screen, YT_PLAYER_HINTS);
                break;
            case FB:
                if (!on(MainActivity.KEY_FB, true)) return;
                tab = selectedTab(root, "Reels", false); // Facebook's tab bar sits at the top
                player = findPlayer(root, screen, NO_HINTS);
                break;
            default:
                return;
        }

        if (on(MainActivity.KEY_DEBUG, false) && now - lastDebug > 1000) {
            lastDebug = now;
            saveDebug(root, pkg, tab, player);
        }

        // A match by shape alone must stay put for a moment, so a normal feed that
        // happens to line up for a split second while scrolling is never blocked.
        if (player != null && !foundByHint) {
            if (shapeSince == 0) shapeSince = now;
            if (now - shapeSince < SHAPE_CONFIRM_MS) {
                handler.removeCallbacks(recheck);
                handler.postDelayed(recheck, SHAPE_CONFIRM_MS + 50);
                player = null;
            }
        } else {
            shapeSince = 0;
        }

        if (tab) {
            block(nope(), false);
            return;
        }
        if (player == null) return; // a short gap (e.g. mid-swipe) does not reset anything

        if (!on(MainActivity.KEY_ALLOW_ONE, false)) {
            block(nope(), false);
            return;
        }
        if (now < cooldownUntil) {
            long min = (cooldownUntil - now) / 60_000 + 1;
            block("Reels rest for " + min + " more min.", false);
            return;
        }

        if (now - playerLastSeen > GONE_MS) { // a newly opened reel
            playerStart = now;
            baseline = null;
            swipeIndex = -1;
            scrolled = 0;
        }
        playerLastSeen = now;

        // Second swipe check: the words on screen (name, caption, sound) were replaced.
        if (now - playerStart > START_IGNORE_MS) {
            Set<String> words = wordsIn(player);
            if (baseline == null) {
                if (words.size() >= 3) baseline = words;
            } else if (replaced(baseline, words)) {
                swiped();
                return;
            }
        }

        long left = GRACE_MS - (now - playerStart);
        if (left <= 0) {
            lockOut("Enough. Reels rest for 5 min.");
            return;
        }
        // Keep checking while the reel stays open, even if the app sends no events.
        handler.removeCallbacks(heartbeat);
        handler.postDelayed(heartbeat, Math.min(left + 100, 1500));
    }

    private boolean on(String key, boolean def) {
        return prefs.getBoolean(key, def);
    }

    /** The block message: a teaching instead of a scolding. */
    private String nope() {
        String[] t = Teachings.random();
        return t[0] + "\n\u2014 " + t[1];
    }

    // ---------------------------------------------------------------- finding the player

    /** Returns the biggest on-screen element that is a full-screen reel player, or null. */
    private AccessibilityNodeInfo findPlayer(AccessibilityNodeInfo root, Rect screen, String[] hints) {
        AccessibilityNodeInfo byHint = null, byShape = null;
        long hintArea = 0, shapeArea = 0;
        Rect r = new Rect();
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        int visited = 0;
        while (!queue.isEmpty() && visited < 400) {
            AccessibilityNodeInfo n = queue.poll();
            visited++;
            if (n == null || !n.isVisibleToUser()) continue;
            n.getBoundsInScreen(r);
            // A player (and anything containing one) covers most of the screen, so smaller
            // elements and everything inside them are skipped. This also keeps reel
            // previews inside the normal feed (about half a screen tall) from matching.
            if (r.height() * 10 < screen.height() * 6) continue;

            long area = (long) r.width() * r.height();
            if (r.height() * 10 >= screen.height() * 7 && hasHint(n, hints)) {
                if (area > hintArea) {
                    byHint = n;
                    hintArea = area;
                }
            } else if (isFullScreenPager(n, r, screen)) {
                if (area > shapeArea) {
                    byShape = n;
                    shapeArea = area;
                }
            }
            addChildren(queue, n);
        }
        foundByHint = byHint != null;
        return byHint != null ? byHint : byShape;
    }

    /** Android can hand back an empty child while a screen is changing; skip those. */
    private static void addChildren(ArrayDeque<AccessibilityNodeInfo> queue, AccessibilityNodeInfo n) {
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c != null) queue.add(c);
        }
    }

    private boolean hasHint(AccessibilityNodeInfo n, String[] hints) {
        String id = n.getViewIdResourceName();
        if (id == null) return false;
        for (String h : hints) if (id.contains(h)) return true;
        return false;
    }

    /**
     * The shape of every reel player: a vertical list that fills the screen, showing
     * exactly one item that lines up with the list's top and bottom edges. A normal
     * feed shows several items, or one that does not line up.
     */
    private boolean isFullScreenPager(AccessibilityNodeInfo n, Rect r, Rect screen) {
        if (!n.isScrollable()) return false;
        if (r.height() < screen.height() * 0.75f || r.width() < screen.width() * 0.9f) return false;
        AccessibilityNodeInfo.CollectionInfo ci = n.getCollectionInfo();
        if (ci == null || ci.getColumnCount() > 1) return false; // unknown or sideways (Stories)
        int tol = Math.max(screen.height() / 50, 8);
        int visible = 0;
        boolean snapped = false;
        Rect c = new Rect();
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo child = n.getChild(i);
            if (child == null || !child.isVisibleToUser()) continue;
            child.getBoundsInScreen(c);
            if (c.height() < tol) continue;
            visible++;
            if (Math.abs(c.top - r.top) <= tol && Math.abs(c.bottom - r.bottom) <= tol
                    && c.width() >= r.width() * 0.9f) snapped = true;
        }
        return snapped && visible == 1;
    }

    // ---------------------------------------------------------------- noticing a swipe

    /** First swipe check: the full-screen list moved to another item, or by half a screen. */
    private boolean isReelSwipe(AccessibilityEvent event) {
        AccessibilityNodeInfo src = event.getSource();
        if (src == null || screenH <= 0) return false;
        Rect r = new Rect();
        src.getBoundsInScreen(r);
        if (r.height() < screenH * 0.75f) return false; // not the player itself

        int idx = event.getFromIndex();
        int dy = 0;
        if (Build.VERSION.SDK_INT >= 28) {
            int dx = event.getScrollDeltaX();
            dy = event.getScrollDeltaY();
            if (Math.abs(dx) > 1 && Math.abs(dy) <= 1) return false; // sideways, not a new reel
            scrolled += dy; // a small drag that springs back cancels itself out
        }
        lastScrollInfo = "scroll: item " + idx + ", moved " + dy + "px, total " + scrolled + "px";
        if (Math.abs(scrolled) >= r.height() / 2) return true;
        if (idx >= 0) {
            if (swipeIndex < 0) swipeIndex = idx;
            else if (idx != swipeIndex) return true;
        }
        return false;
    }

    /** Visible words inside the player, leaving out anything with digits (likes, timers). */
    private Set<String> wordsIn(AccessibilityNodeInfo player) {
        Set<String> out = new HashSet<>();
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(player);
        int visited = 0;
        while (!queue.isEmpty() && visited < 250) {
            AccessibilityNodeInfo n = queue.poll();
            visited++;
            if (n == null || !n.isVisibleToUser()) continue;
            CharSequence t = n.getText() != null ? n.getText() : n.getContentDescription();
            if (t != null) {
                String s = t.toString().trim();
                if (s.length() >= 2 && s.length() <= 80 && !s.matches("(?s).*\\d.*")) out.add(s);
            }
            addChildren(queue, n);
        }
        return out;
    }

    /**
     * A new reel replaces the name, caption and sound, while buttons like "Like" stay.
     * Opening comments or expanding a caption only adds or swaps one or two words.
     */
    private boolean replaced(Set<String> before, Set<String> now) {
        if (now.size() < 3) return false;
        int gone = 0, added = 0;
        for (String s : before) if (!now.contains(s)) gone++;
        for (String s : now) if (!before.contains(s)) added++;
        return gone >= 2 && added >= 2 && gone * 10 >= before.size() * 3;
    }

    private void swiped() {
        lockOut("One reel only. Reels rest for 5 min.");
    }

    private void lockOut(String msg) {
        cooldownUntil = SystemClock.uptimeMillis() + COOLDOWN_MS;
        playerLastSeen = 0;
        baseline = null;
        block(msg, false);
    }

    // ---------------------------------------------------------------- tabs

    private boolean selectedById(AccessibilityNodeInfo root, String pkg, String[] ids) {
        for (String id : ids) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(pkg + ":id/" + id);
            if (nodes == null) continue;
            for (AccessibilityNodeInfo n : nodes) {
                if (n != null && n.isVisibleToUser() && isSelected(n)) return true;
            }
        }
        return false;
    }

    /**
     * True when a short label such as the "Reels" / "Shorts" navigation tab is selected.
     * bottomOnly restricts the match to the bottom navigation bar, so the "Reels" tab
     * on someone's profile page does not count.
     */
    private boolean selectedTab(AccessibilityNodeInfo root, String word, boolean bottomOnly) {
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(word);
        if (nodes == null) return false;
        Rect screen = new Rect();
        root.getBoundsInScreen(screen);
        Rect r = new Rect();
        for (AccessibilityNodeInfo n : nodes) {
            if (n == null || !n.isVisibleToUser()) continue;
            if (!isShortLabel(n, word)) continue; // ignore captions that merely mention the word
            if (bottomOnly) {
                n.getBoundsInScreen(r);
                if (r.centerY() < screen.top + screen.height() * 0.8f) continue;
            }
            if (isSelected(n)) return true;
        }
        return false;
    }

    private boolean isSelected(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 3 && cur != null; i++) {
            if (cur.isSelected()) return true;
            cur = cur.getParent();
        }
        return false;
    }

    private boolean isShortLabel(AccessibilityNodeInfo n, String word) {
        CharSequence t = n.getText() != null ? n.getText() : n.getContentDescription();
        if (t == null) return false;
        String s = t.toString().trim();
        return s.length() <= 30 && s.toLowerCase().startsWith(word.toLowerCase());
    }

    // ---------------------------------------------------------------- acting

    private void block(String msg, boolean goHome) {
        long now = SystemClock.uptimeMillis();
        streak = (now - lastBlock < 2500) ? streak + 1 : 1;
        lastBlock = now;
        // If Back did not get us out twice in a row, leave the app instead of looping.
        performGlobalAction(goHome || streak >= 3 ? GLOBAL_ACTION_HOME : GLOBAL_ACTION_BACK);
        handler.removeCallbacks(recheck);
        handler.removeCallbacks(heartbeat);
        handler.postDelayed(recheck, SETTLE_MS + 50);
        if (streak > 1) return; // count and announce each block only once

        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        String dayKey = MainActivity.DAY_PREFIX + MainActivity.today();
        prefs.edit()
                .putInt(MainActivity.KEY_COUNT, prefs.getInt(MainActivity.KEY_COUNT, 0) + 1)
                .putInt(dayKey, prefs.getInt(dayKey, 0) + 1)
                .apply();
    }

    /** Debug helper: records what was detected and which element names are on screen. */
    private void saveDebug(AccessibilityNodeInfo root, String pkg, boolean tab, AccessibilityNodeInfo player) {
        Set<String> ids = new LinkedHashSet<>();
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        int visited = 0;
        while (!queue.isEmpty() && visited < 1500) {
            AccessibilityNodeInfo n = queue.poll();
            visited++;
            if (n == null) continue;
            String id = n.getViewIdResourceName();
            if (id != null && n.isVisibleToUser()) ids.add(id.replace(pkg + ":id/", ""));
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) queue.add(c);
            }
        }
        String playerInfo = "no";
        if (player != null) {
            String pid = player.getViewIdResourceName();
            playerInfo = "yes, by " + (foundByHint ? "name" : "shape")
                    + " (" + (pid != null ? pid.replace(pkg + ":id/", "") : "unnamed")
                    + ", " + wordsIn(player).size() + " words)";
        }
        prefs.edit().putString(MainActivity.KEY_IDS,
                pkg + "\nlast error: " + prefs.getString(MainActivity.KEY_ERROR, "none")
                        + "\ntab detected: " + tab + "\nplayer detected: " + playerInfo
                        + "\n" + lastScrollInfo + "\n\n" + TextUtils.join(", ", ids)).apply();
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
