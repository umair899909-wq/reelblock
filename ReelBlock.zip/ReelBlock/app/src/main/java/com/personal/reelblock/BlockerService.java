package com.personal.reelblock;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Watches ONLY Instagram, YouTube, Facebook and TikTok (see accessibility_config.xml).
 *
 * Two kinds of screen are recognised:
 *  1. The endless FEED (the Reels tab / Shorts tab)      -> closed instantly.
 *  2. A single video VIEWER opened from a DM, link, etc. -> allowed for a short
 *     time (if the option is on), then closed, followed by a cool-down so the
 *     allowance cannot be used to scroll forever.
 *
 * Nothing is stored except block counters and (only with Debug on) the list of
 * on-screen element IDs. The app has no internet permission.
 */
public class BlockerService extends AccessibilityService {

    static final String IG = "com.instagram.android";
    static final String YT = "com.google.android.youtube";
    static final String FB = "com.facebook.katana";
    static final Set<String> TIKTOK = new HashSet<>(Arrays.asList(
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill"));

    // Internal element IDs. If an app update renames them, use Debug in ReelBlock to find the new ones.
    static final String[] IG_TAB_IDS = { "clips_tab" };
    static final String[] IG_VIEWER_IDS = {
            "clips_viewer_view_pager", "clips_viewer_container", "clips_swipe_refresh_container"
    };
    static final String[] YT_VIEWER_IDS = {
            "reel_recycler", "reel_player_page_container",
            "reel_watch_fragment_root", "reel_watch_player", "shorts_player"
    };

    static final long GRACE_MS = 90_000;        // how long a single opened reel may stay open
    static final long COOLDOWN_MS = 5 * 60_000; // lock-out after the allowance is used up
    static final long SETTLE_MS = 700;          // time given to "Back" before checking again

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable recheck = new Runnable() {
        @Override public void run() { evaluate(); }
    };
    private final Runnable heartbeat = new Runnable() {
        @Override public void run() { evaluate(); }
    };

    private SharedPreferences prefs;
    private long lastCheck, lastBlock, lastDebug;
    private long viewerStart, viewerLastSeen, cooldownUntil;
    private int streak;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (prefs == null) prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);

        long now = SystemClock.uptimeMillis();
        boolean stateChange = event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;

        // Always look once more after the screen has settled, so a throttled event is never missed.
        handler.removeCallbacks(recheck);
        handler.postDelayed(recheck, 350);

        if (!stateChange && now - lastCheck < 250) return; // save battery
        lastCheck = now;
        evaluate();
    }

    private void evaluate() {
        if (prefs == null) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastBlock < SETTLE_MS) return;

        AccessibilityNodeInfo root;
        try {
            root = getRootInActiveWindow();
        } catch (RuntimeException e) {
            return;
        }
        if (root == null || root.getPackageName() == null) return;
        String pkg = root.getPackageName().toString();

        // TikTok is nothing but short videos, so the whole app is closed.
        if (TIKTOK.contains(pkg)) {
            if (on(MainActivity.KEY_TIKTOK, true)) block("TikTok is blocked", true);
            return;
        }

        boolean feed;
        boolean viewer = false;
        switch (pkg) {
            case IG:
                if (!on(MainActivity.KEY_IG, true)) return;
                feed = selectedById(root, pkg, IG_TAB_IDS) || selectedTab(root, "Reels", true);
                viewer = bigVisibleId(root, pkg, IG_VIEWER_IDS);
                break;
            case YT:
                if (!on(MainActivity.KEY_YT, true)) return;
                feed = selectedTab(root, "Shorts", true);
                viewer = bigVisibleId(root, pkg, YT_VIEWER_IDS);
                break;
            case FB:
                if (!on(MainActivity.KEY_FB, true)) return;
                feed = selectedTab(root, "Reels", false); // Facebook's tab bar sits at the top
                break;
            default:
                return;
        }

        if (on(MainActivity.KEY_DEBUG, false) && now - lastDebug > 1000) {
            lastDebug = now;
            saveIds(root, pkg, feed, viewer);
        }

        if (feed) {
            block("Reels / Shorts feed blocked", false);
            return;
        }
        if (!viewer) return;

        if (!on(MainActivity.KEY_GRACE, true)) {
            block("Reels / Shorts blocked", false);
            return;
        }
        if (now < cooldownUntil) {
            long min = (cooldownUntil - now) / 60_000 + 1;
            block("Short videos locked for " + min + " more min", false);
            return;
        }
        if (now - viewerLastSeen > 4000) viewerStart = now; // a newly opened video
        viewerLastSeen = now;
        long left = GRACE_MS - (now - viewerStart);
        if (left <= 0) {
            cooldownUntil = now + COOLDOWN_MS;
            viewerLastSeen = 0;
            block("Time's up - short videos locked for 5 min", false);
            return;
        }
        // Keep checking while the video stays open, even if the app sends no events.
        handler.removeCallbacks(heartbeat);
        handler.postDelayed(heartbeat, Math.min(left + 100, 2000));
    }

    private boolean on(String key, boolean def) {
        return prefs.getBoolean(key, def);
    }

    /** A visible element with one of these IDs that fills at least half the screen height. */
    private boolean bigVisibleId(AccessibilityNodeInfo root, String pkg, String[] ids) {
        Rect screen = new Rect();
        root.getBoundsInScreen(screen);
        Rect r = new Rect();
        for (String id : ids) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(pkg + ":id/" + id);
            if (nodes == null) continue;
            for (AccessibilityNodeInfo n : nodes) {
                if (n == null || !n.isVisibleToUser()) continue;
                n.getBoundsInScreen(r);
                if (r.height() * 2 >= screen.height()) return true;
            }
        }
        return false;
    }

    private boolean selectedById(AccessibilityNodeInfo root, String pkg, String[] ids) {
        for (String id : ids) {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(pkg + ":id/" + id);
            if (nodes == null) continue;
            for (AccessibilityNodeInfo n : nodes) {
                if (n != null && n.isVisibleToUser() && isSelected(n)) return true;
            }
        }
        return false;
    }

    /**
     * True when a short label such as the "Reels" / "Shorts" navigation tab is selected.
     * bottomOnly restricts the match to the bottom navigation bar, so the "Reels" tab
     * on someone's profile page does not count.
     */
    private boolean selectedTab(AccessibilityNodeInfo root, String word, boolean bottomOnly) {
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(word);
        if (nodes == null) return false;
        Rect screen = new Rect();
        root.getBoundsInScreen(screen);
        Rect r = new Rect();
        for (AccessibilityNodeInfo n : nodes) {
            if (n == null || !n.isVisibleToUser()) continue;
            if (!isShortLabel(n, word)) continue; // ignore captions that merely mention the word
            if (bottomOnly) {
                n.getBoundsInScreen(r);
                if (r.centerY() < screen.top + screen.height() * 0.8f) continue;
            }
            if (isSelected(n)) return true;
        }
        return false;
    }

    private boolean isSelected(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 3 && cur != null; i++) {
            if (cur.isSelected()) return true;
            cur = cur.getParent();
        }
        return false;
    }

    private boolean isShortLabel(AccessibilityNodeInfo n, String word) {
        CharSequence t = n.getText() != null ? n.getText() : n.getContentDescription();
        if (t == null) return false;
        String s = t.toString().trim();
        return s.length() <= 30 && s.toLowerCase().startsWith(word.toLowerCase());
    }

    private void block(String msg, boolean goHome) {
        long now = SystemClock.uptimeMillis();
        streak = (now - lastBlock < 2500) ? streak + 1 : 1;
        lastBlock = now;
        // If Back did not get us out twice in a row, leave the app instead of looping.
        performGlobalAction(goHome || streak >= 3 ? GLOBAL_ACTION_HOME : GLOBAL_ACTION_BACK);
        handler.removeCallbacks(recheck);
        handler.postDelayed(recheck, SETTLE_MS + 50);
        if (streak > 1) return; // count and announce each block only once

        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        String day = MainActivity.today();
        int today = day.equals(prefs.getString(MainActivity.KEY_DAY, ""))
                ? prefs.getInt(MainActivity.KEY_TODAY, 0) : 0;
        prefs.edit()
                .putInt(MainActivity.KEY_COUNT, prefs.getInt(MainActivity.KEY_COUNT, 0) + 1)
                .putString(MainActivity.KEY_DAY, day)
                .putInt(MainActivity.KEY_TODAY, today + 1)
                .apply();
    }

    /** Debug helper: records which element IDs are on screen so detection can be repaired after app updates. */
    private void saveIds(AccessibilityNodeInfo root, String pkg, boolean feed, boolean viewer) {
        Set<String> ids = new LinkedHashSet<>();
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        int visited = 0;
        while (!queue.isEmpty() && visited < 1500) {
            AccessibilityNodeInfo n = queue.poll();
            visited++;
            if (n == null) continue;
            String id = n.getViewIdResourceName();
            if (id != null && n.isVisibleToUser()) ids.add(id.replace(pkg + ":id/", ""));
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) queue.add(c);
            }
        }
        prefs.edit().putString(MainActivity.KEY_IDS,
                pkg + "\nfeed detected: " + feed + ", viewer detected: " + viewer + "\n"
                        + TextUtils.join(", ", ids)).apply();
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
