package com.personal.reelblock;

import android.content.SharedPreferences;

import java.time.LocalDate;

/**
 * The streak: how many days in a row the guard has stayed up.
 *
 *  - It starts (or restarts) on the day the guard is raised.
 *  - Lowering the guard, or switching Mushin off in Accessibility, ends it.
 *  - One 10-minute rest a day is free; a second rest on the same day ends it.
 *  - The longest streak is remembered as "best".
 */
final class Streak {

    static final String KEY_START = "streak_start"; // epoch day the streak began, -1 = none
    static final String KEY_BEST = "streak_best";
    static final String KEY_REST_DAY = "rest_day";  // date of the last rest

    static final int[] STEPS = { 1, 3, 7, 14, 30, 60, 100, 365 };
    static final String[] NAMES = {
            "First step", "Finding the path", "Steady hand", "Clear water",
            "Still mountain", "Sharp blade", "No-mind", "Master of the Way"
    };

    static int days(SharedPreferences p) {
        long start = p.getLong(KEY_START, -1);
        if (start < 0) return 0;
        return (int) Math.max(1, LocalDate.now().toEpochDay() - start + 1);
    }

    static int best(SharedPreferences p) {
        return Math.max(p.getInt(KEY_BEST, 0), days(p));
    }

    /** Call whenever the guard is up; starts a streak if none is running. */
    static void begin(SharedPreferences p) {
        if (p.getLong(KEY_START, -1) < 0) {
            p.edit().putLong(KEY_START, LocalDate.now().toEpochDay()).apply();
        }
    }

    /** Call when the guard is lowered; keeps the best and ends the streak. */
    static void end(SharedPreferences p) {
        if (p.getLong(KEY_START, -1) < 0) return;
        p.edit().putInt(KEY_BEST, best(p)).putLong(KEY_START, -1).apply();
    }

    static boolean restedToday(SharedPreferences p) {
        return LocalDate.now().toString().equals(p.getString(KEY_REST_DAY, ""));
    }

    /** Records a rest. The first one each day is free, another one ends the streak. */
    static void rest(SharedPreferences p) {
        if (restedToday(p)) end(p);
        else p.edit().putString(KEY_REST_DAY, LocalDate.now().toString()).apply();
    }

    /** Index of the rank reached with this many days, or -1 before the first day. */
    static int rank(int days) {
        int r = -1;
        for (int i = 0; i < STEPS.length; i++) if (days >= STEPS[i]) r = i;
        return r;
    }

    private Streak() { }
}
